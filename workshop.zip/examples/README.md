# Welcome to your workshop rucksack!

Follow along with today's workshop by viewing `fieldnotes.html` in a (modern) browser. The Field Notes contain code snippets, information about where to find example code, and many links to external references about mobile web topics.

The numbered directories contain examples relevant to each section of the workshop. They are referenced from the field notes.

Hi and welcome!

--Lyza